﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace cleaner
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void cache1_Click(object sender, EventArgs e)
        {
            // Initialize a string to collect all results
            string resultMessage = "";

            // Collect size cleared for each directory
            resultMessage += DeleteFilesInDirectory(@"C:\Windows\Temp") + Environment.NewLine;
            resultMessage += DeleteFilesInDirectory(Environment.GetEnvironmentVariable("TEMP")) + Environment.NewLine;
            resultMessage += DeleteFilesInDirectory(@"C:\Windows\Prefetch");

            // Display a single message box with all results
            MessageBox.Show(resultMessage, "Cache Cleared", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void ram_Click(object sender, EventArgs e)
        {
            ClearRam();
        }

        private string DeleteFilesInDirectory(string directoryPath)
        {
            try
            {
                if (Directory.Exists(directoryPath))
                {
                    long totalSize = 0;

                    // Delete files in the directory
                    foreach (string file in Directory.GetFiles(directoryPath))
                    {
                        try
                        {
                            FileInfo fileInfo = new FileInfo(file);
                            totalSize += fileInfo.Length;
                            File.Delete(file);
                        }
                        catch
                        {
                            // Skip the error and continue deleting other files.
                        }
                    }

                    // Remove empty directories after deleting files
                    RemoveEmptyDirectories(directoryPath);

                    string sizeCleared = FormatSize(totalSize);
                    return $"Cleared {sizeCleared} from {directoryPath}.";
                }
                else
                {
                    return $"The specified directory {directoryPath} does not exist.";
                }
            }
            catch (Exception ex)
            {
                return $"Error accessing the directory {directoryPath}: {ex.Message}";
            }
        }

        private void RemoveEmptyDirectories(string directoryPath)
        {
            try
            {
                // Get all subdirectories
                foreach (var subdirectory in Directory.GetDirectories(directoryPath))
                {
                    // Recursively remove empty directories
                    RemoveEmptyDirectories(subdirectory);
                }

                // Remove the directory if it's empty
                if (Directory.GetFiles(directoryPath).Length == 0 && Directory.GetDirectories(directoryPath).Length == 0)
                {
                    Directory.Delete(directoryPath);
                }
            }
            catch
            {
                // Ignore any errors when trying to delete the directory
            }
        }

        private void ClearRam()
        {
            try
            {
                // Get available memory before cleanup
                ulong availableMemoryBefore = GetAvailableMemory();

                // Clear clipboard
                Clipboard.Clear();

                // Force garbage collection
                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

                // Trim the working set of all processes
                Process[] processes = Process.GetProcesses();
                foreach (Process process in processes)
                {
                    try
                    {
                        SetProcessWorkingSetSize(process.Handle, -1, -1);
                    }
                    catch
                    {
                        // Ignore exceptions for processes that can't be trimmed
                    }
                }

                // Empty standby list
                EmptyStandbyList();

                // Get available memory after cleanup
                ulong availableMemoryAfter = GetAvailableMemory();

                // Calculate cleared memory
                ulong clearedMemory = availableMemoryAfter - availableMemoryBefore;
                string sizeCleared = FormatSize((long)clearedMemory); // Cast clearedMemory to long

                MessageBox.Show($"RAM usage has been minimized. Total memory cleared: {sizeCleared}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error clearing RAM: {ex.Message}");
            }
        }

        private ulong GetAvailableMemory()
        {
            var memoryStatus = new MEMORYSTATUSEX();
            if (GlobalMemoryStatusEx(memoryStatus))
            {
                return memoryStatus.ullAvailPhys;
            }
            return 0;
        }

        private void EmptyStandbyList()
        {
            EmptyWorkingSetList(MEMORY_LIST_TYPE.MEMORY_LIST_TYPE_STANDBY);
        }

        private void EmptyWorkingSetList(MEMORY_LIST_TYPE listType)
        {
            NtSetSystemInformation(SystemMemoryListInformation, ref listType, sizeof(MEMORY_LIST_TYPE));
        }

        private string FormatSize(long size)
        {
            const int scale = 1024;
            string[] orders = new string[] { "GB", "MB", "KB", "Bytes" };
            long max = (long)Math.Pow(scale, orders.Length - 1);

            foreach (string order in orders)
            {
                if (size > max)
                {
                    return string.Format("{0:##.##} {1}", decimal.Divide(size, max), order);
                }

                max /= scale;
            }
            return "0 Bytes";
        }

        [DllImport("kernel32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool SetProcessWorkingSetSize(IntPtr process, int minimumWorkingSetSize, int maximumWorkingSetSize);

        [DllImport("ntdll.dll")]
        static extern int NtSetSystemInformation(int SystemInformationClass, ref MEMORY_LIST_TYPE SystemInformation, int SystemInformationLength);

        private const int SystemMemoryListInformation = 80;

        enum MEMORY_LIST_TYPE
        {
            MEMORY_LIST_TYPE_STANDBY
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        private class MEMORYSTATUSEX
        {
            public uint dwLength;
            public uint dwMemoryLoad;
            public ulong ullTotalPhys;
            public ulong ullAvailPhys;
            public ulong ullTotalPageFile;
            public ulong ullAvailPageFile;
            public ulong ullTotalVirtual;
            public ulong ullAvailVirtual;
            public ulong ullAvailExtendedVirtual;

            public MEMORYSTATUSEX()
            {
                this.dwLength = (uint)Marshal.SizeOf(typeof(MEMORYSTATUSEX));
            }
        }

        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool GlobalMemoryStatusEx([In, Out] MEMORYSTATUSEX lpBuffer);

        private void optimisebtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Close unnecessary background applications
                CloseUnnecessaryBackgroundApplications();

                MessageBox.Show("Optimization complete. Unnecessary background applications have been closed.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error during optimization: {ex.Message}");
            }
        }

        private void CloseUnnecessaryBackgroundApplications()
        {
            // List of processes that are usually background and unnecessary (customize as needed)
            string[] backgroundProcesses = new string[]
            {
                "discord", // Example: Discord is often a background process
                "skype",   // Example: Skype, if not in use
                "teams",   // Example: Microsoft Teams, if not in use
                // Add more process names here as needed
            };

            // Exclude common essential system processes
            string[] essentialProcesses = new string[]
            {
                "explorer", // Windows Explorer
                "system",   // System process
                "services", // Windows services
                // Add more process names here as needed
            };

            foreach (string processName in backgroundProcesses)
            {
                // Check if the process is not in the essential list
                if (!essentialProcesses.Contains(processName))
                {
                    Process[] processes = Process.GetProcessesByName(processName);
                    foreach (Process process in processes)
                    {
                        try
                        {
                            // Ensure the process is actually a background process and not in use
                            if (IsBackgroundProcess(process))
                            {
                                process.Kill();
                                process.WaitForExit(); // Ensure the process is terminated
                            }
                        }
                        catch
                        {
                            // Skip any process that can't be killed
                        }
                    }
                }
            }
        }

        private bool IsBackgroundProcess(Process process)
        {
            // Implement logic to determine if the process is truly a background process
            // For simplicity, you may check if the process has a user interface or other criteria

            try
            {
                return process.MainWindowHandle == IntPtr.Zero; // No main window handle implies background process
            }
            catch
            {
                // In case of any exceptions, assume it's not a background process
                return false;
            }
        }
    }
}
